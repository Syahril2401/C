#include <stdio.h>

int main() {
    int x;

    scanf("%d", &x);  
    printf("- %x -\n", x);  

return 0;
}

