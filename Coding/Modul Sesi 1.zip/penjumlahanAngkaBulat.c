#include <stdio.h>

int main () {
	int a;
	int b;
	int hasil;
	
	printf("Enter first integer\n");
	scanf("%d", &a);
	printf("Enter second integer\n");
	scanf("%d", &b);
	
	hasil = a + b;
	
	printf("Sum is %d\n", hasil);
	
	
return 0;	
}
