#include <stdio.h>
//Muhammad Syahril Alauddin - 2802404551

int main () {
	int umur;
	
	scanf("%d", &umur);
	printf("Selamat ulang tahun yang ke %d yaaa!\n", umur);
	
return 0;
}
