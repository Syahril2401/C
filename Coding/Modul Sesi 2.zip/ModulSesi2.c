#include <stdio.h>

int main () {
	
	int a;
	int b;
	int c;
	int d;
	int e;
	int f;
	int g;
	
	scanf("%d %d", &a, &b);
	
	c = a + b;
	d = a - b;
	e = a * b;
	f = a / b;
	g = a % b;
	
	printf("%d\n", c);
	printf("%d\n", d);
	printf("%d\n", e);
	printf("%d\n", f);
	printf("%d\n", g);
	
return 0;	
}
