#include <stdio.h>

//#semogabenar:)

int main () {
	
	printf("        *\n"); 
    printf("                *\n"); 
    printf("                        *\n"); 
    printf("                                *\n"); 
    printf("                                        *\n");										
    printf("                                                *\n");
	printf("                                        *\n");	
	printf("                                *\n"); 
	printf("                        *\n"); 
	printf("                *\n");
	printf("        *\n"); 
	
					
	
return 0;
}
